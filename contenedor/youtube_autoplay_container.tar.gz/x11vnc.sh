#!/bin/bash

export DISPLAY=:0
x11vnc -display :0 -nopw -forever -shared &
