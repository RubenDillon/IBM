#!/bin/bash

export DISPLAY=:0

chromium-browser --no-sandbox --disable-gpu --disable-software-rasterizer --window-size=1920,1080 --start-fullscreen --kiosk "https://www.youtube.com/watch?v=AWFPhBKeea4" &

sleep 600

pkill -f chromium-browser
