#!/bin/bash

Xvfb :0 -screen 0 1920x1080x24 &

./x11vnc.sh &

./watch_once.sh &

/home/appuser/noVNC/utils/novnc_proxy --vnc localhost:5900 --listen 8080
